package com.yu.app.moudles.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.yu.common.entity.app.GoodsCategory;

public interface GoodsCategoryMapper extends BaseMapper<GoodsCategory> {
}
