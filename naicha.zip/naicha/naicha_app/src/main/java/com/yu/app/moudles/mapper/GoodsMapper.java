package com.yu.app.moudles.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.yu.common.entity.app.Goods;

public interface GoodsMapper extends BaseMapper<Goods> {


}
