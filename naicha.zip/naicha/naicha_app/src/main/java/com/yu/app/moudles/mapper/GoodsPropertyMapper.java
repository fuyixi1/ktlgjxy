package com.yu.app.moudles.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.yu.common.entity.app.GoodsProperty;

public interface GoodsPropertyMapper extends BaseMapper<GoodsProperty> {


}
