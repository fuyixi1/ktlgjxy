通用包
里面的类是公用的基本不变，如数据库表对象，一些工具类
一些配置暂时配置在com.yu.config.property下的类里面
小程序相关配置在entity包下的AppConfig类里