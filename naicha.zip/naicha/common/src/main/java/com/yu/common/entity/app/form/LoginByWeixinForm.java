package com.yu.common.entity.app.form;

import lombok.Data;

@Data
public class LoginByWeixinForm {
    private String code;
    private String wxAvatar;
}
