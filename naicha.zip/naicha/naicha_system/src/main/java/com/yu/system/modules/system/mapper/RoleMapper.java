package com.yu.system.modules.system.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.yu.common.entity.system.Role;

public interface RoleMapper extends BaseMapper<Role> {
}
