package com.yu.system.modules.app.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.yu.common.entity.app.User;

/**
 * 
 */
public interface UserAdminMapper extends BaseMapper<User> {

}
